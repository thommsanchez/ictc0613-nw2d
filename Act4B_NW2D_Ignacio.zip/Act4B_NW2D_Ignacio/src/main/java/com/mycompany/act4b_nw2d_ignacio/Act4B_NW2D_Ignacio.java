
package com.mycompany.act4b_nw2d_ignacio;

import java.util.Scanner;

public class Act4B_NW2D_Ignacio {

    public static void main(String[] args) {
  
		Scanner scan = new Scanner (System.in);
		
			int array1, array2, pos;
		
		System.out.println("Number of elements is: ") ;
 		array2 = scan.nextInt();
		int[] a = new int[array2];
 
    		System.out.println("Enter the numbers: ") ;
    		for( array1 = 0; array1 <array2; array1++ )
    		{
        		a[array1] = scan.nextInt();
    		}
		
    		
    	Scanner input = new Scanner (System.in);
    	System.out.println("Press 1 if you will delete an array");
    	System.out.println("Press 2 if not");
    	
    	int choice = input.nextInt();
    	
    	switch (choice) {
    		case 1: System.out.println("Location of number to be deleted: ");
     		pos = scan.nextInt();
	   		
    		for( array1 = pos; array1 <array2-1; array1++)
    	    	{
            		a[array1]=a[array1+1];
        		}
        			array2 = array2-1;
        		
        		for( array1 = 0; array1 < array2; array1++) 
        		{
            		System.out.println("a["+array1+"] = "+a[array1]);
        		}
        		break;
    			case 2:	System.out.println("\n Elements of Array: \n");
        		for( array1 = 0; array1 < array2; array1++) 
        		{
            		System.out.println("a["+array1+"] = "+a[array1]);
        		}
    			break;
    			default: System.out.println("Invalid Choice");
    			break;

    	}
    	
		
	}
	
}

    