

package com.mycompany.act4b_nw2d_gajesan;

import java.util.Scanner;
public class Act4B_NW2D_Gajesan {

  

    public static void main(String[] args) {
  
		Scanner scan = new Scanner (System.in);
		
			int arr1, arr2, location;
		
		System.out.println("Number of elements is: ") ;
 		arr2 = scan.nextInt();
		int[] a = new int[arr2];
 
    		System.out.println("Enter the numbers: ") ;
    		for( arr1 = 0; arr1 <arr2; arr1++ )
    		{
        		a[arr1] = scan.nextInt();
    		}
		
    		
    	Scanner input = new Scanner (System.in);
    	System.out.println("Press 1 if you want to delete an array");
    	System.out.println("Press 2 if not");
    	
    	int choice = input.nextInt();
    	
    	switch (choice) {
    		case 1: System.out.println("Location of number to be deleted: ");
     		location = scan.nextInt();
	   		
    		for( arr1 = location; arr1 <arr2-1; arr1++)
    	    	{
            		a[arr1]=a[arr1+1];
        		}
        			arr2 = arr2-1;
        		
        		for( arr1 = 0; arr1 < arr2; arr1++) 
        		{
            		System.out.println("a["+arr1+"] = "+a[arr1]);
        		}
        		break;
    			case 2:	System.out.println("\n Elements of Array: \n");
        		for( arr1 = 0; arr1 < arr2; arr1++) 
        		{
            		System.out.println("a["+arr1+"] = "+a[arr1]);
        		}
    			break;
    			default: System.out.println("Invalid Choice");
    			break;

    	}
    	
		
	}
	
}

    